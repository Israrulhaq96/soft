import './quizstyle.css';
import QuizeComp from "./data/QuizeComp";
export default function App() {

  return (
<>
   <div>
    <QuizeComp/>
   </div>
   </>
  );
}

