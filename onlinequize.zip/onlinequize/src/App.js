
import React from "react";
import Quiz from "./Quiz.js";

//I get the the idea from this site  //https://www.trafficsigntest.com.pk/SignTest/Index/15

export default function App() {

  return (

    <div>
      <Quiz/>
    </div>


  );
}

