import React, { useState } from "react";
import Question from "./data/Question.json";
//I get the the idea from this site  //https://www.trafficsigntest.com.pk/SignTest/Index/15
function Quiz(){
let [currentQIndex, setCurrentQIndex] = useState(0);
  let [selectedOptionIndex, setSelectedOptionIndex] = useState(0);
  const onOptionSelected = (Question, selectedOptionIndex) => {
    setSelectedOptionIndex(selectedOptionIndex)
        // const ans=Question.correctOptionIndex=== selectedOptionIndex;
  
  }

  
 
  
  
  const nextQuestion = () => {
    setSelectedOptionIndex(null);
    setCurrentQIndex(currentQIndex + 1);
  }

  const restart = () => {
    setCurrentQIndex(0);
  }

  if (currentQIndex === Question.length) {
    return (
      <div className="container my-5">
        <h3> Quiz Finish !</h3>
        <button onClick={restart}> Restart </button>
      </div>
    )
  }
  
  return (

    <div className="container my-5">
      <div className="card text-center">
        <div className="card-header">
          <h1 className="card-title">Online Quiz for Driving licence</h1>
        </div>
        <div className="card-body , card mb-5" key={Question[currentQIndex]?.id}>
          <h5 className="card-title">{Question[currentQIndex]?.statement}</h5>

        </div>
        <ul className="list-group list-group-flush">
          {Question[currentQIndex]?.options.map((option, index) => 
          (<button className="btn btn-primary" style={{ alignSelf: 'center',width:"150", height:"150" }}  onClick={nextQuestion} >
            <img src={option}  className={selectedOptionIndex === index ? "list-group-item active" : "list-group-item"}
              key={index}
              onClick={() => onOptionSelected(index)} /></button>
          ))}
        </ul>
      </div>
    </div>


  );
}
export default Quiz